
package javaapplication5.principal;
//Esta la lógica en MVC son las fórmulas para las conversiones que va a ser leidas desde otras

import javax.swing.JOptionPane;

public class ConvertirMonedas {  //usamos double en vez de big decimal
    public void ConvertirPesosAdollar(double valorRecibido){   
        double monedaDollar = valorRecibido / 18;
        monedaDollar = (double) Math.round(monedaDollar * 100d)/100;  //1
        JOptionPane.showMessageDialog(null,"Tienes $ " +monedaDollar+ " Dólares"); //2
    }
    //lo mismo pero para Euros
        public void ConvertirPesosAEuros(double valorRecibido){   
        double monedaEuros = valorRecibido / 16;  
        monedaEuros = (double) Math.round(monedaEuros * 100)/100;  //1
        JOptionPane.showMessageDialog(null,"Tienes $ " +monedaEuros+ " Euros"); //2
    }

//1 mostrar solo 2 decimales
//2 mostrar el valor de la conversion
//en java no se usa la , para separar solo el punto

//ya solo falta llamar estos métodos en la clase principal parsarle valores y dar el resultado
//pero no se pondrán ahi , se podria hacerlo pero en su lugar se creará en la clase function.java
}
