package javaapplication5.principal;


import javax.swing.JOptionPane;


public class Funcion {
 //conversion y descoversion de la moneda
     //Instancia  
    ConvertirMonedas monedas = new ConvertirMonedas();
    
    public void ConvertirMonedas(double ValorRecibido){
        //estoy creando mi metodo refiriendome a la clase del mismo nombre
    String opciones=(JOptionPane.showInputDialog(null,
        "Elige la moneda a la que deseas convertir tu dinero ", "Monedas",
        JOptionPane.INFORMATION_MESSAGE, null,
        new Object[]{"De pesos a Dollar", "De pesos a Euro", "De pesos a libras", "De pesos a Yen", "De pesos a Won sul-coreano",  "De Dolar a pesos", "De Euros a pesos" ,"De libras a pesos","De Yen japonés a pesos","De Won sul-coreano a pesos" }, "Selección")).toString(); // } )) aqui no va { sino antes de "Selección"
    switch(opciones){
    case "De pesos a Dollar": //estaba como P y no p, luego de eso De pesos a Dolar funcionó
        monedas.ConvertirPesosAdollar(ValorRecibido);   
        break;//llama a cada metodo de la clase Convertir Monedas en este caso empezó por el 1ero ConvertirPesosAdolares CORRECCION es ConvertirPesosAdollar(asi proviene de la clase)
        //tuvimos que instanciar o crear un objeto para acceder a los metodos de la CLASE   ConvertirMonedas
    case "De pesos a Euro":
        monedas.ConvertirPesosAEuros(ValorRecibido);
        break;
}
    }   
}
