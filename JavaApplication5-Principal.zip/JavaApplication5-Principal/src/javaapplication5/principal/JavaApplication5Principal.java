package javaapplication5.principal;

import javax.swing.JOptionPane;

public class JavaApplication5Principal {

        /* https://docs.oracle.com/javase/7/docs/api/javax/swing/JOptionPane.html*/
        
    public static void main(String[] args) {
         //LLAMANDO A LA CLASE function de function.java
        Funcion monedas =  new Funcion(); 
//Se tiene que llamar igual que la clase a la que llama, en este caso a Function.java
      //Y SE TIENE QUE PONER DENTRO DEL PAQUETE CORRECTO SINO NO DETECTA LA CLASE DESDE OTRA
      //do{
      //char Menu;
      //char op=0;
      boolean sal = false;
     // do{ EL DO MANTIENE EL CICLO INFINITO
     do{
          String opciones=(JOptionPane.showInputDialog(null,
        "Seleccione de la lista un opción de conversión", "Menú",
        JOptionPane.INFORMATION_MESSAGE, null,
        new Object[]{"Conversor de Moneda", "opcion 2"}, "Selección")).toString(); 
        
      
        
switch(opciones){
    case "Conversor de Moneda":  //omiti el }  si lo pongo tengo que poner otro que cierre
        String input = JOptionPane.showInputDialog("Ingrese un valor para convertir"); //1 
     double ValorRecibido = Double.parseDouble(input); 
//se requiere convertir el dato ingresado y pasarlo de string a double o decimal
     monedas.ConvertirMonedas(ValorRecibido); //el valor del input acabado de colocar por el usuario ya convertido a Double   Y APARTE ESTA LLAMANDO AL METODO ConvertirMonedas()
     int seleccion=JOptionPane.showConfirmDialog(null, "¿Deseas realizar otra conversión?");
       if(JOptionPane.OK_OPTION == seleccion){ //If(seleccion==JOption.OK_OPTION)
           System.out.println("Selecciona opción Afirmativa");
           //break;
       } else{
          ///sal=false;
           //JOptionPane.showMessageDialog(null,"Programa terminado");
           if(seleccion==JOptionPane.NO_OPTION){ //if NO option selected
               System.out.println("Programa terminado");
               
       }else if (seleccion==JOptionPane.CLOSED_OPTION){
               System.out.println("(adios)");
       } //sal=true;
}
       }
    //} ESTA ERA DEL do SE QUITÓ PARA QUE SE DETUVIERA EL CICLO 
     } while(sal=!sal); 
    //while(!sal==sal); 
    //while(!sal && sal);
    //while(sal=!sal);--esta es casi correcta
    //while(!sal);
    //while(op!='Conversor de Moneda');
     // while(opciones !='Selección');
    } 
    
    
}


/*JavaApplication5Principal RegresaAlMenu = JavaApplication5Principal();
 private static void regresarMenu() {     Con sout+tab es System.out.printl y ctrl + espacio acompleta instrucción */